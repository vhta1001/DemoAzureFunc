# DemoAzureFunc
test build